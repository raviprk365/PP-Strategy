---
applyTo: "**/*.yml,**/*.yaml,**/.github/workflows/**,**/azure-pipelines*"
---

# CI/CD Pipelines for Power Platform — GitHub Copilot Instructions

> Use this file when creating deployment pipelines for Power Platform solutions.

---

## 1. Role

You are a DevOps engineer building CI/CD pipelines for Power Platform. You automate solution export, build, test, and deployment across Dev → Test → Production environments using GitHub Actions or Azure DevOps.

---

## 2. Project Context

<!--
  ╔══════════════════════════════════════════════════════════════╗
  ║  PLACEHOLDER: Define your environments                      ║
  ╚══════════════════════════════════════════════════════════════╝
-->

| Environment | URL | Purpose |
|-------------|-----|---------|
| Dev | `{{https://org-dev.crm.dynamics.com}}` | Development |
| Test | `{{https://org-test.crm.dynamics.com}}` | Testing / QA |
| Production | `{{https://org.crm.dynamics.com}}` | Production |

| Setting | Value |
|---------|-------|
| Solution Name | `{{SOLUTION_NAME}}` |
| CI/CD Platform | `{{GitHub Actions / Azure DevOps}}` |
| Auth Method | `{{Service Principal / Username-Password}}` |

---

## 3. GitHub Actions — Export from Dev

```yaml
name: Export Solution from Dev

on:
  workflow_dispatch:
  schedule:
    - cron: '0 6 * * 1-5'  # Weekdays at 6am UTC

env:
  SOLUTION_NAME: {{SolutionName}}
  SOLUTION_EXPORTED_FOLDER: out/exported/
  SOLUTION_FOLDER: out/solutions/

jobs:
  export:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
        with:
          ref: ${{ github.head_ref }}

      - name: Install Power Platform CLI
        uses: microsoft/powerplatform-actions/actions-install@v1

      - name: Who Am I
        uses: microsoft/powerplatform-actions/who-am-i@v1
        with:
          environment-url: ${{ secrets.DEV_ENVIRONMENT_URL }}
          app-id: ${{ secrets.CLIENT_ID }}
          client-secret: ${{ secrets.CLIENT_SECRET }}
          tenant-id: ${{ secrets.TENANT_ID }}

      - name: Export Unmanaged Solution
        uses: microsoft/powerplatform-actions/export-solution@v1
        with:
          environment-url: ${{ secrets.DEV_ENVIRONMENT_URL }}
          app-id: ${{ secrets.CLIENT_ID }}
          client-secret: ${{ secrets.CLIENT_SECRET }}
          tenant-id: ${{ secrets.TENANT_ID }}
          solution-name: ${{ env.SOLUTION_NAME }}
          solution-output-file: ${{ env.SOLUTION_EXPORTED_FOLDER }}/${{ env.SOLUTION_NAME }}.zip

      - name: Unpack Solution
        uses: microsoft/powerplatform-actions/unpack-solution@v1
        with:
          solution-file: ${{ env.SOLUTION_EXPORTED_FOLDER }}/${{ env.SOLUTION_NAME }}.zip
          solution-folder: ${{ env.SOLUTION_FOLDER }}/${{ env.SOLUTION_NAME }}
          solution-type: 'Both'

      - name: Commit to Source Control
        run: |
          git config user.name "GitHub Actions"
          git config user.email "actions@github.com"
          git add --all
          git commit -m "Export ${{ env.SOLUTION_NAME }} from Dev [skip ci]" || echo "No changes"
          git push
```

---

## 4. GitHub Actions — Deploy to Test / Production

```yaml
name: Deploy Solution

on:
  push:
    branches: [main]
    paths:
      - 'out/solutions/**'

jobs:
  build-managed:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install Power Platform CLI
        uses: microsoft/powerplatform-actions/actions-install@v1

      - name: Pack Managed Solution
        uses: microsoft/powerplatform-actions/pack-solution@v1
        with:
          solution-folder: out/solutions/${{ env.SOLUTION_NAME }}
          solution-file: out/managed/${{ env.SOLUTION_NAME }}_managed.zip
          solution-type: 'Managed'

      - name: Upload Artifact
        uses: actions/upload-artifact@v4
        with:
          name: managed-solution
          path: out/managed/

  deploy-test:
    needs: build-managed
    runs-on: windows-latest
    environment: Test
    steps:
      - uses: actions/download-artifact@v4
        with:
          name: managed-solution
          path: out/managed/

      - name: Install Power Platform CLI
        uses: microsoft/powerplatform-actions/actions-install@v1

      - name: Import to Test
        uses: microsoft/powerplatform-actions/import-solution@v1
        with:
          environment-url: ${{ secrets.TEST_ENVIRONMENT_URL }}
          app-id: ${{ secrets.CLIENT_ID }}
          client-secret: ${{ secrets.CLIENT_SECRET }}
          tenant-id: ${{ secrets.TENANT_ID }}
          solution-file: out/managed/${{ env.SOLUTION_NAME }}_managed.zip
          force-overwrite: true
          import-as-holding: false

  deploy-prod:
    needs: deploy-test
    runs-on: windows-latest
    environment: Production
    steps:
      - uses: actions/download-artifact@v4
        with:
          name: managed-solution
          path: out/managed/

      - name: Install Power Platform CLI
        uses: microsoft/powerplatform-actions/actions-install@v1

      - name: Import to Production
        uses: microsoft/powerplatform-actions/import-solution@v1
        with:
          environment-url: ${{ secrets.PROD_ENVIRONMENT_URL }}
          app-id: ${{ secrets.CLIENT_ID }}
          client-secret: ${{ secrets.CLIENT_SECRET }}
          tenant-id: ${{ secrets.TENANT_ID }}
          solution-file: out/managed/${{ env.SOLUTION_NAME }}_managed.zip
          force-overwrite: true

env:
  SOLUTION_NAME: {{SolutionName}}
```

---

## 5. Code Apps Deployment (Separate Pipeline)

```yaml
name: Deploy Code App

on:
  push:
    branches: [main]
    paths:
      - 'src/**'
      - 'package.json'

jobs:
  build-and-push:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - run: npm ci
      - run: npm run build

      - name: Install Power Platform CLI
        uses: microsoft/powerplatform-actions/actions-install@v1

      - name: Authenticate
        run: pac auth create --url ${{ secrets.ENVIRONMENT_URL }} --applicationId ${{ secrets.CLIENT_ID }} --clientSecret ${{ secrets.CLIENT_SECRET }} --tenant ${{ secrets.TENANT_ID }}

      - name: Push Code App
        run: pac code push
```

---

## 6. Required Secrets

| Secret | Used For | Notes |
|--------|----------|-------|
| `CLIENT_ID` | All environments | Azure AD App Registration |
| `CLIENT_SECRET` | All environments | App Registration secret |
| `TENANT_ID` | All environments | Azure AD tenant |
| `DEV_ENVIRONMENT_URL` | Export from Dev | Dev environment URL |
| `TEST_ENVIRONMENT_URL` | Deploy to Test | Test environment URL |
| `PROD_ENVIRONMENT_URL` | Deploy to Prod | Production environment URL |

---

## 7. Service Principal Setup

```bash
# Register the App in Azure AD, then grant Power Platform permissions:
pac admin assign-user \
  --environment {{ENV_URL}} \
  --user {{APP_ID}} \
  --role "System Administrator" \
  --application-user
```

---

## References

- [Power Platform Actions for GitHub](https://github.com/microsoft/powerplatform-actions)
- [Power Platform Build Tools for Azure DevOps](https://learn.microsoft.com/en-us/power-platform/alm/devops-build-tools)
- [ALM for Power Platform](https://learn.microsoft.com/en-us/power-platform/alm/)
