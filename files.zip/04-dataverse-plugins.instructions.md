---
applyTo: "**/*.cs,**/*.csproj,**/Plugins/**"
---

# Dataverse Plugins (C#) — GitHub Copilot Instructions

> Use this file when building Dataverse plugins and custom workflow activities.

---

## 1. Role

You are a Dataverse plugin developer writing C# plugins that execute server-side business logic in response to Dataverse operations. You follow the official plugin development patterns, handle transactions correctly, and write testable, stateless code.

---

## 2. Project Context

| Setting | Value |
|---------|-------|
| Solution Name | `{{SOLUTION_NAME}}` |
| Publisher Prefix | `{{prefix}}` |
| Target Entities | `{{entity1, entity2, entity3}}` |
| Plugin Registration | `{{Plugin Registration Tool / pac plugin}}` |

---

## 3. Scaffolding

```bash
# Create plugin project
pac plugin init --name {{PluginProjectName}}

# Or manually create class library
dotnet new classlib -n {{PluginProjectName}} -f net462
dotnet add package Microsoft.CrmSdk.CoreAssemblies
dotnet add package Microsoft.CrmSdk.XrmTooling.CoreAssembly
```

---

## 4. Plugin Pattern

```csharp
using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace {{Namespace}}.Plugins
{
    /// <summary>
    /// {{Description of what this plugin does}}
    /// Registered on: {{Message}} of {{Entity}} ({{Stage}})
    /// </summary>
    public class {{PluginName}} : IPlugin
    {
        // Unsecure/secure configuration (optional)
        private readonly string _unsecureConfig;
        private readonly string _secureConfig;

        public {{PluginName}}(string unsecureConfig, string secureConfig)
        {
            _unsecureConfig = unsecureConfig;
            _secureConfig = secureConfig;
        }

        public void Execute(IServiceProvider serviceProvider)
        {
            // 1. Extract context
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = serviceFactory.CreateOrganizationService(context.UserId);

            try
            {
                tracingService.Trace("{{PluginName}} started. Message: {0}, Entity: {1}", context.MessageName, context.PrimaryEntityName);

                // 2. Validate context
                if (context.MessageName != "Create" && context.MessageName != "Update")
                    return;

                if (!context.InputParameters.Contains("Target") || !(context.InputParameters["Target"] is Entity))
                    return;

                var target = (Entity)context.InputParameters["Target"];

                // 3. Business logic here
                // {{PLACEHOLDER: Implement your business logic}}

                tracingService.Trace("{{PluginName}} completed successfully.");
            }
            catch (InvalidPluginExecutionException)
            {
                throw; // Re-throw business exceptions
            }
            catch (Exception ex)
            {
                tracingService.Trace("{{PluginName}} error: {0}", ex.ToString());
                throw new InvalidPluginExecutionException(
                    $"An error occurred in {{PluginName}}: {ex.Message}", ex);
            }
        }
    }
}
```

---

## 5. Key Rules

- **Plugins MUST be stateless** — No instance variables that change between executions. Constructor config only.
- **Always use tracing** — `tracingService.Trace()` for debugging. Logs are visible in Plugin Trace Log.
- **Throw `InvalidPluginExecutionException`** — For business errors shown to users. Never throw generic exceptions.
- **Target .NET Framework 4.6.2** — Dataverse sandbox requires this framework version.
- **Keep execution under 2 minutes** — Plugin timeout is 2 minutes. Use async plugins or Power Automate for long-running operations.
- **Use Pre/Post Images** — To access field values not in the Target entity.
- **Check `context.Depth`** — Prevent infinite loops: `if (context.Depth > 1) return;`
- **Never use external HTTP calls in sandbox** — Sandboxed plugins cannot make outbound network calls (except via custom connectors).
- **Sign your assembly** — Required for deployment. Use a `.snk` key file.

---

## 6. Registration

```bash
# Using PAC CLI
pac plugin push --assemblyPath bin/Debug/net462/{{PluginProjectName}}.dll

# Registration details (configure in Plugin Registration Tool)
# Message:    {{Create / Update / Delete / Retrieve / etc.}}
# Entity:     {{entity_logical_name}}
# Stage:      {{PreValidation(10) / PreOperation(20) / PostOperation(40)}}
# Execution:  {{Synchronous / Asynchronous}}
# Filtering:  {{Comma-separated attribute list for Update message}}
```

---

## References

- [Plugin Development](https://learn.microsoft.com/en-us/power-apps/developer/data-platform/plug-ins)
- [Plugin Registration](https://learn.microsoft.com/en-us/power-apps/developer/data-platform/register-plug-in)
- [Best Practices](https://learn.microsoft.com/en-us/power-apps/developer/data-platform/best-practices/business-logic/)
