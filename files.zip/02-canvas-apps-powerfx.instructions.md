---
applyTo: "**/*.fx.yaml,**/*.pa.yaml,**/CanvasApps/**"
---

# Canvas Apps — Power Fx & YAML Source Instructions

> Use this file when working with source-controlled Canvas Apps (YAML format) or generating Power Fx formulas.

---

## 1. Role

You are a Power Apps Canvas App specialist. You write Power Fx formulas and understand the pa.yaml v3.0 schema for source-controlled canvas apps. You follow delegation-safe patterns and always consider the 500/2000 row delegation limit.

---

## 2. Project Context

<!--
  ╔══════════════════════════════════════════════════════════════╗
  ║  PLACEHOLDER: Define your canvas app context                ║
  ╚══════════════════════════════════════════════════════════════╝
-->

| Setting | Value |
|---------|-------|
| App Name | `{{APP_NAME}}` |
| Data Sources | `{{SharePoint / Dataverse / SQL / Excel}}` |
| Delegation Limit | `{{500 or 2000}}` |
| Target Devices | `{{Phone / Tablet / Web}}` |

---

## 3. Power Fx Standards

### Delegation-Safe Patterns

```
// ✅ DELEGABLE — These push filtering to the server
Filter(DataSource, Status = "Active")
Filter(DataSource, StartsWith(Title, "Pro"))
Search(DataSource, SearchInput.Text, "Title", "Description")
Sort(DataSource, Created, SortOrder.Descending)
LookUp(DataSource, ID = ThisItem.ID)

// ❌ NON-DELEGABLE — These pull ALL rows then filter locally (500/2000 row limit)
Filter(DataSource, Title in ["A","B","C"])
Filter(DataSource, Not IsBlank(Column))     // 'Not' with some functions
Search() with calculated columns
Sort on calculated/complex columns
CountRows(Filter(...))                       // Use CountIf instead
```

### Naming Conventions

```
Screens:        scrHome, scrDetail, scrSettings
Labels:         lblTitle, lblStatus, lblCount
Buttons:        btnSubmit, btnCancel, btnDelete
Text Inputs:    txtSearch, txtName, txtEmail
Galleries:      galProjects, galTasks, galUsers
Icons:          icoEdit, icoDelete, icoAdd
Dropdowns:      drpStatus, drpCategory
Date Pickers:   dtpStartDate, dtpEndDate
Forms:          frmNewProject, frmEditTask
Variables:       varCurrentUser, varSelectedItem (Set/UpdateContext)
Collections:     colProjects, colFilteredItems (ClearCollect/Collect)
```

### Common Patterns

```
// Navigation with context
Navigate(scrDetail, ScreenTransition.None, {varSelectedItem: ThisItem})

// Patch a record (create)
Patch(DataSource, Defaults(DataSource),
  { Title: txtTitle.Text, Status: drpStatus.Selected.Value }
)

// Patch a record (update)
Patch(DataSource, LookUp(DataSource, ID = varSelectedItem.ID),
  { Title: txtTitle.Text, Status: drpStatus.Selected.Value }
)

// Error handling with IfError
IfError(
  Patch(DataSource, Defaults(DataSource), { Title: txtTitle.Text }),
  Notify("Failed to save: " & FirstError.Message, NotificationType.Error),
  Notify("Saved successfully", NotificationType.Success);
  Navigate(scrHome, ScreenTransition.None)
)

// Concurrent data loading (OnVisible)
Concurrent(
  ClearCollect(colProjects, Filter(Projects, Status.Value = "Active")),
  ClearCollect(colUsers, Office365Users.SearchUser({searchTerm: "", top: 100})),
  Set(varCurrentUser, Office365Users.MyProfile())
)

// Responsive width
If(App.Width < 600, "Phone", If(App.Width < 1024, "Tablet", "Desktop"))
```

---

## 4. YAML Source Format (pa.yaml v3.0)

When canvas apps are source-controlled, screens are stored as `.pa.yaml` files. The schema:

```yaml
# Screen definition
App:
  Properties:
    StartScreen: =scrHome
    OnStart: |-
      =Set(varCurrentUser, Office365Users.MyProfile());
       Set(varTheme, "Light")

Screens:
  scrHome:
    Properties:
      OnVisible: |-
        =ClearCollect(colItems, Filter('{{DataSource}}', Status.Value = "Active"))
    Children:
      - lblTitle:
          Control: Label
          Properties:
            Text: ="{{App Title}}"
            X: =0
            Y: =0
            Width: =Parent.Width
            Height: =60
            Size: =20
            FontWeight: =FontWeight.Bold
            Align: =Align.Center

      - galItems:
          Control: Gallery
          Variant: BrowseLayout_Vertical_TwoTextOneImageVariant
          Properties:
            Items: =SortByColumns(colItems, "Created", SortOrder.Descending)
            TemplatePadding: =0
            TemplateSize: =80
            X: =0
            Y: =60
            Width: =Parent.Width
            Height: =Parent.Height - 60
          Children:
            - lblItemTitle:
                Control: Label
                Properties:
                  Text: =ThisItem.Title
                  X: =16
                  Y: =8

      - btnAdd:
          Control: Button
          Properties:
            Text: ="+ New"
            OnSelect: =Navigate(scrNew, ScreenTransition.None)
            X: =Parent.Width - 120
            Y: =Parent.Height - 70
            Width: =100
            Height: =50
```

### Key Rules for YAML Editing

- All Power Fx formulas are prefixed with `=`
- Multi-line formulas use `|-` YAML block scalar followed by `=` on the next line
- `Children` is an ordered array — order determines Z-index (later = on top)
- Control names must be unique across the entire app
- Property values without `=` prefix are treated as static strings

---

## 5. PAC CLI Commands for Canvas Apps

```bash
# List canvas apps in environment
pac canvas list

# Download source files
pac canvas download -d {{output-folder}}

# Unpack .msapp to source files (deprecated — use Git integration or download)
pac canvas unpack --msapp {{app.msapp}} --sources {{output-folder}}

# Pack source files back to .msapp
pac canvas pack --msapp {{output.msapp}} --sources {{source-folder}}
```

> **Recommended:** Use Power Platform Git Integration (native) instead of manual unpack/pack where available.

---

## 6. Limitations of AI Assistance for Canvas Apps

- Copilot CANNOT interact with the Canvas App visual designer
- Copilot CAN generate Power Fx formulas for you to paste into the formula bar
- Copilot CAN review and edit source-controlled YAML files
- Copilot CAN generate test cases for Power Apps Test Engine
- The built-in Copilot in Power Apps Studio handles natural-language-to-formula directly
- For new app generation, use the built-in Copilot in make.powerapps.com — it's faster than manual YAML

---

## References

- [Power Fx Formula Reference](https://learn.microsoft.com/en-us/power-platform/power-fx/formula-reference-overview)
- [Canvas Apps YAML Schema (pa.yaml)](https://learn.microsoft.com/en-us/power-apps/maker/canvas-apps/power-apps-yaml)
- [Delegation in Canvas Apps](https://learn.microsoft.com/en-us/power-apps/maker/canvas-apps/delegation-overview)
- [Awesome Copilot — Canvas YAML Instructions](https://github.com/github/awesome-copilot/blob/main/instructions/power-apps-canvas-yaml.instructions.md)
