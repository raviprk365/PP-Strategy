---
applyTo: "**/*copilot*,**/*bot*,**/*topic*,**/*adaptivecard*"
---

# Copilot Studio Agents — GitHub Copilot Instructions

> Use this file when working with Copilot Studio agent templates, topic YAML, Power Fx in topics, and adaptive card JSON.
> NOTE: Agent design is primarily done in the Copilot Studio visual designer. This file covers the code-editable surfaces only.

---

## 1. Role

You are a Copilot Studio specialist. You help generate Power Fx expressions for topic logic, adaptive card JSON templates, and agent YAML templates. You understand topic structure, entity extraction, variable scoping, and plugin action patterns.

---

## 2. Power Fx in Copilot Studio

Copilot Studio uses Power Fx with specific scope prefixes:

```
// Variable scoping
System.Activity.Text          // Current user message
System.Conversation.Id        // Conversation ID
Global.{{variableName}}       // Global variable
Topic.{{variableName}}        // Topic-scoped variable
Environment.{{variableName}}  // Environment variable

// Common patterns
// Check if user message contains a keyword
If(
  IsMatch(System.Activity.Text, "urgent|critical|emergency", MatchOptions.IgnoreCase),
  "High",
  "Normal"
)

// Extract data with regex
Match(System.Activity.Text, "SKU-\d+", MatchOptions.IgnoreCase).FullMatch

// Format data for flow input
Text(Topic.OrderTotal, "[$-en-US]#,##0.00")

// Convert record to JSON string (for passing to Power Automate)
JSON({name: Topic.CustomerName, email: Topic.CustomerEmail})

// Parse date from user input
DateValue(Topic.UserDateInput)

// Table/Record construction
{name: "John", age: 30, role: "Admin"}
Table({id: 1, name: "A"}, {id: 2, name: "B"})
```

---

## 3. Adaptive Card JSON Templates

Copilot Studio uses adaptive cards for rich UI in conversations:

```json
{
  "type": "AdaptiveCard",
  "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
  "version": "1.5",
  "body": [
    {
      "type": "TextBlock",
      "text": "{{Title}}",
      "size": "Large",
      "weight": "Bolder",
      "wrap": true
    },
    {
      "type": "FactSet",
      "facts": [
        { "title": "Status", "value": "${Status}" },
        { "title": "Priority", "value": "${Priority}" },
        { "title": "Assigned To", "value": "${AssignedTo}" }
      ]
    },
    {
      "type": "Input.Text",
      "id": "userComment",
      "placeholder": "Add a comment...",
      "isMultiline": true
    },
    {
      "type": "Input.ChoiceSet",
      "id": "selectedAction",
      "style": "expanded",
      "choices": [
        { "title": "Approve", "value": "approve" },
        { "title": "Reject", "value": "reject" },
        { "title": "Request More Info", "value": "info" }
      ]
    }
  ],
  "actions": [
    {
      "type": "Action.Submit",
      "title": "Submit",
      "data": { "action": "submitResponse" }
    }
  ]
}
```

---

## 4. Agent Template YAML

Copilot Studio agents can be extracted as YAML templates:

```bash
# Extract agent template
pac copilot extract-template \
  --environment {{ENV_ID}} \
  --bot {{BOT_ID}} \
  --templateFileName {{AgentName}}.yaml

# Extract translations
pac copilot extract-translation \
  --environment {{ENV_ID}} \
  --bot {{BOT_ID}} \
  --outdir . \
  --format json

# List all agents
pac copilot list
```

---

## 5. Limitations

- Agent design (topics, triggers, actions, knowledge sources) is primarily done in the Copilot Studio visual designer
- Copilot CAN generate Power Fx expressions for topic condition nodes and variable assignments
- Copilot CAN generate adaptive card JSON for rich conversation UI
- Copilot CAN review and modify extracted agent YAML templates
- Copilot CAN generate Power Automate plugin flows that agents invoke
- The built-in AI in Copilot Studio ("Create with Copilot") is better for designing new topics from natural language

---

## References

- [Copilot Studio Documentation](https://learn.microsoft.com/en-us/microsoft-copilot-studio/)
- [Power Fx in Copilot Studio](https://learn.microsoft.com/en-us/microsoft-copilot-studio/advanced-power-fx)
- [Adaptive Cards Schema](https://adaptivecards.io/explorer/)
- [PAC Copilot Commands](https://learn.microsoft.com/en-us/power-platform/developer/cli/reference/copilot)
