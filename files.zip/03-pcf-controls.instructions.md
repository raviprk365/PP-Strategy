---
applyTo: "**/*.pcfproj,**/ControlManifest.Input.xml,**/pcf/**"
---

# PCF Controls — GitHub Copilot Instructions

> Use this file when building PowerApps Component Framework (PCF) controls.

---

## 1. Role

You are a PCF control developer building reusable components for Canvas Apps and Model-Driven Apps using React, TypeScript, and Fluent UI 9.

---

## 2. Project Context

| Setting | Value |
|---------|-------|
| Control Name | `{{CONTROL_NAME}}` |
| Namespace | `{{NAMESPACE}}` |
| Control Type | `{{field / dataset}}` |
| Target Apps | `{{Canvas / Model-Driven / Both}}` |
| Framework | React (using `--framework react` flag) |

---

## 3. Scaffolding

```bash
# Initialise React-based PCF control
pac pcf init -n {{ControlName}} -ns {{Namespace}} -t {{field|dataset}} -fw react -npm

# Build and test in harness
npm start

# Build for production
npm run build

# Package into solution
mkdir {{SolutionFolder}} && cd {{SolutionFolder}}
pac solution init --publisher-name {{PublisherName}} --publisher-prefix {{prefix}}
pac solution add-reference --path ../{{ControlName}}
dotnet build
```

---

## 4. Coding Standards

### Manifest (ControlManifest.Input.xml)

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest>
  <control namespace="{{Namespace}}" constructor="{{ControlName}}" version="1.0.0"
           display-name-key="{{ControlName}}" description-key="{{Description}}"
           control-type="standard">
    <!-- Field-bound property -->
    <property name="sampleProperty" display-name-key="Sample" description-key="Sample property"
              of-type="SingleLine.Text" usage="bound" required="true" />

    <!-- Dataset property (for dataset controls) -->
    <data-set name="sampleDataSet" display-name-key="Sample Data Set">
      <property-set name="sampleProperty" display-name-key="Column" of-type="SingleLine.Text" />
    </data-set>

    <!-- Platform libraries (React + Fluent) -->
    <platform-library name="React" version="16.14.0" />
    <platform-library name="Fluent" version="9.46.2" />

    <resources>
      <code path="index.ts" order="1" />
    </resources>
  </control>
</manifest>
```

### React Control Pattern

```typescript
import * as React from 'react';
import { FluentProvider, webLightTheme } from '@fluentui/react-components';
import type { IInputs, IOutputs } from './generated/ManifestTypes';

// Main component
const {{ControlName}}App: React.FC<{ context: ComponentFramework.Context<IInputs> }> = ({ context }) => {
  // Access bound property
  const value = context.parameters.sampleProperty.raw ?? '';

  return (
    <FluentProvider theme={webLightTheme}>
      {/* Component content */}
    </FluentProvider>
  );
};

// PCF Control class
export class {{ControlName}} implements ComponentFramework.ReactControl<IInputs, IOutputs> {
  private notifyOutputChanged: () => void;

  public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void): void {
    this.notifyOutputChanged = notifyOutputChanged;
  }

  public updateView(context: ComponentFramework.Context<IInputs>): React.ReactElement {
    return React.createElement({{ControlName}}App, { context });
  }

  public getOutputs(): IOutputs {
    return {};
  }

  public destroy(): void {}
}
```

### Key Rules

- **Use platform libraries** — Do NOT bundle React or Fluent UI. Declare them in the manifest.
- **Use `ShadingType.CLEAR`** — Never SOLID for shading.
- **Always use Fluent UI 9** — Consistent with Power Platform look and feel.
- **Handle `null` and `undefined`** — PCF properties can be null. Always use nullish coalescing.
- **Call `notifyOutputChanged()`** — Whenever output values change.
- **Keep bundles small** — Platform libraries are shared, so your bundle should be lightweight.
- **Test in harness first** — `npm start` launches the PCF test harness before deploying.

---

## References

- [PCF Overview](https://learn.microsoft.com/en-us/power-apps/developer/component-framework/overview)
- [React Controls & Platform Libraries](https://learn.microsoft.com/en-us/power-apps/developer/component-framework/react-controls-platform-libraries)
- [PCF Tutorial](https://learn.microsoft.com/en-us/power-apps/developer/component-framework/implementing-controls-using-typescript)
