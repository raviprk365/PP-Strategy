# Power Platform — AI-Assisted Development: Engineering Assessment & Copilot Instructions

> **Author:** Engineering Specialist Assessment
> **Date:** February 2026
> **Purpose:** Define where GitHub Copilot / Claude Code instruction files genuinely reduce the development lifecycle across Power Platform, and provide ready-to-use instruction files for each supported area.

---

## Assessment Matrix

| Area | Copilot Instructions? | AI Impact | Reasoning |
|------|----------------------|-----------|-----------|
| **Code Apps (React/TS)** | ✅ YES — Full instructions | ★★★★★ | Full code-first project in VS Code. Copilot has full context. Highest ROI. |
| **Canvas Apps (YAML + Power Fx)** | ✅ YES — Formula & YAML reference | ★★★★☆ | Canvas Apps now export as YAML (pa.yaml v3.0). Power Fx formulas can be generated. Git integration supported. |
| **PCF Controls (React/TS)** | ✅ YES — Full instructions | ★★★★★ | Full TypeScript/React project. Same dev experience as Code Apps. |
| **Dataverse Plugins (C#)** | ✅ YES — Full instructions | ★★★★★ | Standard C# class library. Copilot excels here. |
| **Custom Connectors (OpenAPI)** | ✅ YES — Spec generation | ★★★★☆ | OpenAPI/Swagger JSON definitions. Copilot generates and validates specs efficiently. |
| **Power Automate (Flow JSON)** | ⚠️ PARTIAL — Expression reference only | ★★★☆☆ | Flows are JSON definitions but primarily visual. AI helps with complex expressions, not flow design. |
| **Copilot Studio Agents** | ⚠️ PARTIAL — Topic YAML + Power Fx only | ★★☆☆☆ | Mostly visual designer. Templates extractable via `pac copilot extract-template`. AI helps with Power Fx in topics and adaptive card JSON. |
| **Model-Driven Apps** | ❌ NO — Use built-in Copilot | ★☆☆☆☆ | Almost entirely metadata/UI configuration. No meaningful code surface for Copilot instructions. Use Microsoft's built-in Copilot and Generative Pages instead. |
| **Generative Pages** | ❌ NO — Use built-in AI | ★☆☆☆☆ | AI-generated React pages within MDA. The built-in AI IS the tool — no external instructions needed. |
| **CI/CD Pipelines (YAML)** | ✅ YES — Full instructions | ★★★★★ | Standard GitHub Actions / Azure DevOps YAML. Copilot generates pipelines extremely well. |
| **Solution ALM** | ✅ YES — CLI reference | ★★★★☆ | `pac solution` commands for export/unpack/pack/import. Copilot helps with scripting and automation. |
| **Power Apps Test Engine** | ✅ YES — Test generation | ★★★★☆ | Power Fx test steps in YAML. Microsoft officially supports Copilot-assisted test authoring. |

---

## Files Included

| File | Area | Description |
|------|------|-------------|
| `01-code-apps.instructions.md` | Code Apps | Full React/TypeScript Code Apps development on Power Platform |
| `02-canvas-apps-powerfx.instructions.md` | Canvas Apps | Power Fx formula reference + YAML schema for source-controlled canvas apps |
| `03-pcf-controls.instructions.md` | PCF Controls | PowerApps Component Framework controls (React/TypeScript) |
| `04-dataverse-plugins.instructions.md` | Dataverse Plugins | C# plugin development for Dataverse |
| `05-custom-connectors.instructions.md` | Custom Connectors | OpenAPI/Swagger definition generation and validation |
| `06-power-automate-expressions.instructions.md` | Power Automate | Expression reference for complex flow expressions |
| `07-copilot-studio-topics.instructions.md` | Copilot Studio | Topic YAML templates, Power Fx in topics, and adaptive card JSON |
| `08-cicd-pipelines.instructions.md` | CI/CD | GitHub Actions and Azure DevOps pipelines for Power Platform |
| `09-solution-alm.instructions.md` | Solution ALM | PAC CLI commands for solution lifecycle management |
| `10-test-engine.instructions.md` | Test Engine | Power Apps Test Engine with Copilot-assisted test authoring |

---

## How to Use

### Single Project
Pick the relevant file(s) for your project type and place them in your `.github/` folder:
```
.github/
├── copilot-instructions.md              # Use 01-code-apps as the base
├── 02-canvas-apps-powerfx.instructions.md   # If your solution includes canvas apps
├── 08-cicd-pipelines.instructions.md    # For deployment automation
└── 09-solution-alm.instructions.md      # For solution management
```

### Multi-Component Solution
For solutions that span multiple component types (common in enterprise), combine the relevant files. GitHub Copilot reads ALL `.instructions.md` files in `.github/`.

### Placeholder Convention
All files use `{{PLACEHOLDER}}` syntax for project-specific values. Search and replace these before use.

---

## What NOT to Create Instructions For

### Model-Driven Apps
- Configuration is 95% visual (forms, views, dashboards, business rules)
- Use Microsoft's built-in Copilot in the MDA designer instead
- The only code surfaces (JavaScript web resources) are better covered by general JS/TS instructions

### Generative Pages
- The entire point is that AI generates the React code FOR you
- Accessible via `https://aka.ms/PowerAppsEAP` or Vibe.PowerApps.com
- No external Copilot instructions needed — the built-in AI IS the development tool

### Power BI
- Primarily visual report design with DAX/M formulas
- DAX/M are niche languages that general Copilot handles reasonably without instructions
- Microsoft's built-in Copilot in Power BI is the better tool here

---

## Recommendations

1. **Start with Code Apps (01) + CI/CD (08)** — This combination delivers the highest immediate ROI for any team adopting AI-assisted Power Platform development.

2. **Add Canvas Apps (02) if you have existing canvas apps** — The YAML source format + Power Fx reference helps Copilot generate accurate formulas and review source-controlled apps.

3. **PCF Controls (03) and Plugins (04) are essential for pro-dev teams** — These are full code projects where Copilot operates at maximum effectiveness.

4. **Test Engine (10) is an emerging high-value area** — Microsoft officially supports Copilot-assisted test authoring. Adopt early for competitive advantage.

5. **Custom Connectors (05) are underrated** — Copilot generates OpenAPI specs extremely well. This eliminates one of the most tedious manual tasks in Power Platform development.

6. **Power Automate (06) and Copilot Studio (07) have limited but real value** — Use these instruction files as expression/formula references, not as full development guides. The visual designers remain primary for these tools.
