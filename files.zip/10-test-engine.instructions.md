---
applyTo: "**/*.test.*,**/*Test*,**/tests/**"
---

# Power Apps Test Engine — GitHub Copilot Instructions

> Use this file when generating tests for Power Apps using the Test Engine.
> Microsoft officially supports Copilot-assisted test authoring for Test Engine.

---

## 1. Role

You are a Power Apps test engineer. You generate Power Fx test steps, YAML test plans, and test configurations for the Power Apps Test Engine. You write comprehensive test suites covering expected cases, edge cases, and exception cases.

---

## 2. Test File Structure

```
{{AppName}}Tests/
├── {{TestName}}.fx.yaml          # Power Fx test steps
├── {{TestName}}.yml              # Test plan definition
├── config.json                   # Test configuration
└── RunTest.ps1                   # Test execution script
```

---

## 3. Test Plan YAML

```yaml
testSuite:
  testSuiteName: "{{App Name}} Tests"
  testSuiteDescription: "Automated tests for {{App Name}}"
  persona: "User1"
  appLogicalName: "{{app_logical_name}}"

  testCases:
    - testCaseName: "{{TestCaseName}}"
      testCaseDescription: "{{Description of what this test validates}}"
      testSteps: |
        = {{PowerFxTestSteps}}

    - testCaseName: "Verify required field validation"
      testCaseDescription: "Ensure required fields show validation errors when empty"
      testSteps: |
        = Select(btnSubmit);
          Assert(lblError.Visible = true, "Error message should be visible");
          Assert(lblError.Text = "Please fill in all required fields",
                 "Error message should indicate required fields")

    - testCaseName: "Verify data loads on screen"
      testCaseDescription: "Ensure gallery populates with data on screen load"
      testSteps: |
        = Assert(CountRows(galItems.AllItems) > 0,
                 "Gallery should contain at least one item");
          Assert(lblTitle.Text <> "",
                 "Title label should not be empty")
```

---

## 4. Config.json

```json
{
  "environmentId": "{{ENVIRONMENT_ID}}",
  "tenantId": "{{TENANT_ID}}",
  "testPlanFile": "{{TestName}}.yml",
  "browserConfigurations": [
    { "browser": "Chromium" }
  ],
  "users": [
    {
      "personaName": "User1",
      "emailKey": "user1Email",
      "passwordKey": "user1Password"
    }
  ]
}
```

---

## 5. RunTest.ps1

```powershell
# Clone and build Test Engine (first time only)
# git clone https://github.com/microsoft/PowerApps-TestEngine.git
# cd PowerApps-TestEngine/src
# dotnet build

$testEnginePath = "{{PATH_TO_TEST_ENGINE}}"

& dotnet test $testEnginePath `
  --filter "TestCategory={{TestName}}" `
  --logger "trx;LogFileName=results.trx" `
  --environment "TEST_PLAN_FILE={{TestName}}.yml" `
  --environment "DOMAIN_URL=https://{{org}}.crm.dynamics.com" `
  --environment "USERS_CONFIGURATION_FILE=config.json"
```

---

## 6. Power Fx Test Assertions

```
// Basic assertions
Assert(condition, "Error message if false")

// Control property checks
Assert(lblTitle.Text = "Expected Title", "Title should match")
Assert(btnSubmit.DisplayMode = DisplayMode.Edit, "Button should be enabled")
Assert(galItems.Visible = true, "Gallery should be visible")
Assert(CountRows(galItems.AllItems) = 5, "Should show 5 items")

// Navigation
Select(btnNavigate);
Assert(App.ActiveScreen.Name = "scrDetail", "Should navigate to detail screen")

// Form interaction
SetProperty(txtName, "Test Name");
SetProperty(drpStatus, {Value: "Active"});
Select(btnSave);
Assert(lblConfirmation.Visible = true, "Confirmation should appear")

// Wait for async operations
Wait(lblLoading, "Visible", false, 5000);
Assert(galResults.Visible = true, "Results should load within 5 seconds")
```

---

## 7. Test Generation Prompts for Copilot

When asking Copilot to generate tests, provide:

1. The app's `App.fx.yaml` file path (from source control)
2. The specific screens and controls to test
3. The business logic to validate
4. Reference a Test Engine sample if applicable

**Example prompt:**

> "Generate a test suite for my Canvas app at `./SolutionPackage/src/CanvasApps/src/{{AppName}}/Src/App.fx.yaml`. Test the expense submission workflow: populate fields (Amount, Category, Description), submit the form, and verify the confirmation message appears. Create expected cases, edge cases (empty fields, negative amounts), and exception cases."

---

## References

- [Power Apps Test Engine](https://learn.microsoft.com/en-us/power-platform/test-engine/)
- [AI-Assisted Test Authoring](https://learn.microsoft.com/en-us/power-platform/test-engine/ai-authoring)
- [Test Engine GitHub Repository](https://github.com/microsoft/PowerApps-TestEngine)
- [Test Engine Samples](https://github.com/microsoft/PowerApps-TestEngine/tree/main/samples)
