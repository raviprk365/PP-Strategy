---
applyTo: "**/Solution.xml,**/Customizations.xml,**/*.cdsproj"
---

# Solution ALM — GitHub Copilot Instructions

> Use this file when managing Power Platform solutions via PAC CLI.

---

## 1. Role

You are a Power Platform ALM specialist managing solution lifecycle: export, source control, environment migration, and deployment automation.

---

## 2. PAC Solution Commands

```bash
# === AUTHENTICATION ===
pac auth create --url {{ENV_URL}}
pac auth create --url {{ENV_URL}} --applicationId {{APP_ID}} --clientSecret {{SECRET}} --tenant {{TENANT_ID}}
pac auth list
pac auth select --index {{N}}
pac env select --environment {{ENV_URL_OR_ID}}

# === EXPORT ===
pac solution export --name {{SolutionName}} --path {{output.zip}}
pac solution export --name {{SolutionName}} --path {{output.zip}} --managed

# === UNPACK (source control) ===
pac solution unpack --zipfile {{output.zip}} --folder {{unpacked-folder}}
pac solution unpack --zipfile {{output.zip}} --folder {{unpacked-folder}} --packagetype Both

# === PACK ===
pac solution pack --zipfile {{managed.zip}} --folder {{unpacked-folder}} --packagetype Managed
pac solution pack --zipfile {{unmanaged.zip}} --folder {{unpacked-folder}} --packagetype Unmanaged

# === IMPORT ===
pac solution import --path {{solution.zip}}
pac solution import --path {{solution.zip}} --force-overwrite --activate-plugins

# === OTHER ===
pac solution list                                    # List solutions in environment
pac solution delete --solution-name {{Name}}         # Delete solution
pac solution check --path {{solution.zip}}           # Run solution checker
pac solution create-settings --solution-zip {{zip}} --settings-file {{settings.json}}
pac solution clone --name {{SolutionName}}           # Clone to local for editing
pac solution online-version --solution-name {{Name}} --solution-version {{1.0.0.1}}
```

---

## 3. Unpacked Solution Structure

```
{{SolutionFolder}}/
├── Other/
│   └── Solution.xml              # Solution metadata (version, publisher, dependencies)
├── Entities/                     # Dataverse table definitions
│   └── {{entity}}/
│       ├── Entity.xml
│       ├── FormXml/              # Forms (Main, Quick Create, Card)
│       ├── SavedQueries/         # Views
│       └── Charts/               # Charts
├── Workflows/                    # Power Automate flows (JSON definitions)
│   └── {{flowname}}.json
├── CanvasApps/                   # Canvas app source files
│   └── {{appname}}/
│       └── src/                  # pa.yaml source files
├── WebResources/                 # JavaScript, HTML, CSS, images
├── PluginAssemblies/             # Plugin DLLs
├── Roles/                        # Security roles
├── OptionSets/                   # Global option sets
├── ConnectionReferences/         # Connection references
├── EnvironmentVariableDefinitions/ # Environment variables
└── customizations.xml            # Remaining customisations
```

---

## 4. Environment Variables & Connection References

```bash
# Create deployment settings file
pac solution create-settings --solution-zip {{solution.zip}} --settings-file deploymentSettings.json

# deploymentSettings.json structure:
# {
#   "EnvironmentVariables": [
#     {
#       "SchemaName": "{{prefix}}_{{VarName}}",
#       "Value": "{{target-environment-value}}"
#     }
#   ],
#   "ConnectionReferences": [
#     {
#       "LogicalName": "{{prefix}}_{{ConnRefName}}",
#       "ConnectionId": "{{target-environment-connection-id}}"
#     }
#   ]
# }

# Import with settings
pac solution import --path {{solution.zip}} --settings-file deploymentSettings.json
```

---

## 5. Key Rules

- **Always use managed solutions in Test/Prod** — Unmanaged only in Dev
- **Never edit directly in Test/Prod** — All changes flow from Dev via CI/CD
- **Use connection references** — Not direct connections, for environment portability
- **Use environment variables** — For values that change between environments
- **Version your solutions** — Increment on every export: `1.0.0.X`
- **Run solution checker** — Before deployment: `pac solution check --path {{zip}}`

---

## References

- [ALM for Power Platform](https://learn.microsoft.com/en-us/power-platform/alm/)
- [PAC Solution Commands](https://learn.microsoft.com/en-us/power-platform/developer/cli/reference/solution)
- [Solution Concepts](https://learn.microsoft.com/en-us/power-platform/alm/solution-concepts-alm)
