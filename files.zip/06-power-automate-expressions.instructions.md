---
applyTo: "**/*flow*,**/*workflow*,**/*automate*"
---

# Power Automate — Expression Reference for GitHub Copilot

> Use this file as a reference when generating complex Power Automate expressions.
> NOTE: Flow design is primarily done in the visual designer. This file helps Copilot generate accurate expressions, JSON transformations, and flow definition snippets.

---

## 1. Role

You are a Power Automate specialist. You help generate complex expressions, JSON transformations, condition logic, and flow definition snippets. You understand the expression language, connector actions, and common flow patterns.

---

## 2. Common Expression Patterns

### String Operations
```
// Concatenate
concat('Hello ', triggerOutputs()?['body/firstname'], ' ', triggerOutputs()?['body/lastname'])

// Format date
formatDateTime(utcNow(), 'yyyy-MM-dd')
formatDateTime(triggerOutputs()?['body/createdon'], 'dd/MM/yyyy HH:mm')

// Replace
replace(variables('myString'), 'old', 'new')

// Substring
substring(variables('myString'), 0, 10)

// Convert to upper/lower
toUpper(triggerOutputs()?['body/name'])
toLower(triggerOutputs()?['body/email'])

// Check if contains
contains(triggerOutputs()?['body/description'], 'urgent')

// Split and join
split(variables('csvString'), ',')
join(variables('myArray'), '; ')
```

### Date & Time
```
// Current UTC time
utcNow()

// Add days/hours/minutes
addDays(utcNow(), 7)
addHours(utcNow(), 2)
addMinutes(utcNow(), 30)

// Difference between dates (returns ticks — divide for days)
div(sub(ticks(variables('endDate')), ticks(variables('startDate'))), 864000000000)

// Start of day/month/year
startOfDay(utcNow())
startOfMonth(utcNow())

// Day of week (0=Sunday)
dayOfWeek(utcNow())

// Convert timezone
convertFromUtc(utcNow(), 'AUS Eastern Standard Time', 'yyyy-MM-dd HH:mm')
convertTimeZone(triggerOutputs()?['body/createdon'], 'UTC', '{{Target Timezone}}')
```

### Conditional Logic
```
// If expression
if(equals(triggerOutputs()?['body/status'], 'Active'), 'Yes', 'No')

// Coalesce (first non-null)
coalesce(triggerOutputs()?['body/nickname'], triggerOutputs()?['body/firstname'], 'Unknown')

// Null check
if(empty(triggerOutputs()?['body/email']), 'No email', triggerOutputs()?['body/email'])
```

### Array / Collection
```
// Length
length(outputs('List_rows')?['body/value'])

// First / Last
first(outputs('List_rows')?['body/value'])
last(outputs('List_rows')?['body/value'])

// Filter array (use in Filter Array action expression)
@equals(item()?['Status'], 'Active')

// Select specific properties (use in Select action)
// From: outputs('List_rows')?['body/value']
// Map: { "Name": item()?['name'], "Email": item()?['email'] }

// Union / Intersection
union(variables('array1'), variables('array2'))
intersection(variables('array1'), variables('array2'))

// Create array
createArray('item1', 'item2', 'item3')
```

### JSON Operations
```
// Parse JSON (use after HTTP or Get Items)
// Schema generation: paste sample payload into Parse JSON action

// Access nested JSON
body('Parse_JSON')?['data']?['items']

// Create JSON object
json(concat('{"name":"', variables('name'), '","value":', variables('count'), '}'))

// Convert to/from string
string(variables('myObject'))
json(variables('myJsonString'))
```

### Dynamic Content References
```
// Trigger outputs (when a record is created/modified)
triggerOutputs()?['body/{{column_logical_name}}']
triggerOutputs()?['body/_{{lookup_field}}_value']          // Lookup ID
triggerOutputs()?['body/{{lookup_field}}@OData.Community.Display.V1.FormattedValue']  // Lookup display name

// Action outputs
outputs('{{Action_Name}}')?['body/{{property}}']
outputs('{{Action_Name}}')?['headers/{{header}}']
outputs('{{Action_Name}}')?['statusCode']

// Loop current item (inside Apply to Each)
items('Apply_to_each')?['{{property}}']
```

---

## 3. Common Flow Patterns

### Error Handling (Try-Catch-Finally)

```
Scope: "Try"
  → Actions that might fail
  → Configure Run After: Succeeded

Scope: "Catch"
  → Configure Run After: has failed, has timed out, is skipped
  → result('Try')  // Gets the outcome of the Try scope
  → actions('{{Failed_Action}}')?['outputs']?['body']?['error']?['message']

Scope: "Finally"
  → Configure Run After: Succeeded, has failed, has timed out, is skipped
  → Cleanup actions (e.g., send notification, update status)
```

### Pagination (Loop Until All Records)

```
Initialise variable: varSkip = 0
Initialise variable: varHasMore = true

Do Until: varHasMore equals false
  → List Rows (with $top=5000, $skip=varSkip)
  → Condition: length(outputs('List_rows')?['body/value']) equals 0
    Yes → Set varHasMore = false
    No  → Process records + Set varSkip = add(variables('varSkip'), 5000)
```

### Approval with Timeout

```
Start and Wait for Approval
  → Parallel Branch: Delay (e.g., 7 days)
  → After Delay: Update record as "Timed Out"
  → After Approval: Check outcome, Update record
```

---

## 4. Flow Definition Export/Import

Power Automate flows export as JSON within solutions. The key file is the `workflow.json`:

```bash
# Export solution containing flows
pac solution export --name {{SolutionName}} --path {{output.zip}}

# Unpack to see flow definitions
pac solution unpack --zipfile {{output.zip}} --folder {{unpacked-folder}}

# Flow definitions are in:
# {{unpacked-folder}}/Workflows/{{flow-name}}.json
```

Copilot can help review, compare, and modify these JSON flow definitions when unpacked.

---

## 5. Limitations

- Flow DESIGN is primarily visual — Copilot cannot interact with the flow designer
- Copilot CAN generate expressions for you to paste into expression fields
- Copilot CAN review unpacked flow JSON definitions
- Copilot CAN generate GitHub Actions / Azure DevOps YAML for flow deployment
- The built-in Copilot in Power Automate ("Describe it to design it") is better for creating new flows from scratch

---

## References

- [Expression Reference](https://learn.microsoft.com/en-us/azure/logic-apps/workflow-definition-language-functions-reference)
- [Power Automate Documentation](https://learn.microsoft.com/en-us/power-automate/)
- [Connector Reference](https://learn.microsoft.com/en-us/connectors/connector-reference/)
