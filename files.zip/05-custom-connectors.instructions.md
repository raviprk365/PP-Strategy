---
applyTo: "**/*swagger*,**/*openapi*,**/*connector*,**/*apiDefinition*"
---

# Custom Connectors (OpenAPI) — GitHub Copilot Instructions

> Use this file when creating or editing Power Platform custom connectors.

---

## 1. Role

You are a Power Platform integration specialist creating custom connectors. You write OpenAPI 2.0 (Swagger) definitions that Power Platform can consume. You understand authentication patterns, pagination, triggers, and connector certification requirements.

---

## 2. Project Context

| Setting | Value |
|---------|-------|
| Connector Name | `{{CONNECTOR_NAME}}` |
| Base URL | `{{https://api.example.com/v1}}` |
| Auth Type | `{{API Key / OAuth 2.0 / Basic / None}}` |
| Target API | `{{Description of the API being connected}}` |

---

## 3. OpenAPI 2.0 Template

Power Platform custom connectors use **OpenAPI 2.0 (Swagger)**, NOT OpenAPI 3.0.

```json
{
  "swagger": "2.0",
  "info": {
    "title": "{{Connector Name}}",
    "description": "{{Description of what this connector does}}",
    "version": "1.0.0",
    "contact": {
      "name": "{{Team Name}}",
      "email": "{{team@company.com}}"
    }
  },
  "host": "{{api.example.com}}",
  "basePath": "/{{v1}}",
  "schemes": ["https"],
  "consumes": ["application/json"],
  "produces": ["application/json"],
  "securityDefinitions": {
    "api_key": {
      "type": "apiKey",
      "in": "header",
      "name": "{{X-API-Key}}"
    }
  },
  "security": [{ "api_key": [] }],
  "paths": {
    "/{{resource}}": {
      "get": {
        "operationId": "Get{{Resources}}",
        "summary": "List all {{resources}}",
        "description": "Retrieves a list of {{resources}}",
        "parameters": [
          {
            "name": "top",
            "in": "query",
            "type": "integer",
            "description": "Number of records to return",
            "default": 50
          },
          {
            "name": "skip",
            "in": "query",
            "type": "integer",
            "description": "Number of records to skip",
            "default": 0
          }
        ],
        "responses": {
          "200": {
            "description": "Success",
            "schema": {
              "type": "object",
              "properties": {
                "value": {
                  "type": "array",
                  "items": { "$ref": "#/definitions/{{Resource}}" }
                }
              }
            }
          }
        }
      },
      "post": {
        "operationId": "Create{{Resource}}",
        "summary": "Create a {{resource}}",
        "parameters": [
          {
            "name": "body",
            "in": "body",
            "required": true,
            "schema": { "$ref": "#/definitions/{{Resource}}Create" }
          }
        ],
        "responses": {
          "201": {
            "description": "Created",
            "schema": { "$ref": "#/definitions/{{Resource}}" }
          }
        }
      }
    }
  },
  "definitions": {
    "{{Resource}}": {
      "type": "object",
      "properties": {
        "id": { "type": "string", "description": "Unique identifier" },
        "name": { "type": "string", "description": "Display name" },
        "createdAt": { "type": "string", "format": "date-time" }
      }
    },
    "{{Resource}}Create": {
      "type": "object",
      "required": ["name"],
      "properties": {
        "name": { "type": "string", "description": "Display name" }
      }
    }
  }
}
```

---

## 4. Key Rules

- **OpenAPI 2.0 ONLY** — Power Platform does NOT support OpenAPI 3.0 natively.
- **Every operation needs `operationId`** — Must be unique, PascalCase, no spaces.
- **Define `x-ms-summary`** — Adds friendly display names in Power Automate / Power Apps.
- **Define `x-ms-visibility`** — `"important"`, `"advanced"`, or `"internal"` to control UI display.
- **Response schemas are required** — Without them, output properties won't be available in flows.
- **Use `$ref` for shared definitions** — Keep the spec DRY.
- **Test with `pac connector`** — `pac connector create` and `pac connector update` for deployment.

---

## 5. PAC CLI Commands

```bash
# Create connector from OpenAPI definition
pac connector create --api-definition-file {{apiDefinition.json}}

# Update existing connector
pac connector update --connector-id {{CONNECTOR_ID}} --api-definition-file {{apiDefinition.json}}

# Download existing connector definition
pac connector download --connector-id {{CONNECTOR_ID}} --outputDirectory {{folder}}

# List connectors
pac connector list
```

---

## References

- [Custom Connectors Overview](https://learn.microsoft.com/en-us/connectors/custom-connectors/)
- [OpenAPI Extensions for Connectors](https://learn.microsoft.com/en-us/connectors/custom-connectors/openapi-extensions)
- [Connector Certification](https://learn.microsoft.com/en-us/connectors/custom-connectors/submit-certification)
